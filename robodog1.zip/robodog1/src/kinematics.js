const { radToDegree, lerp, clamp } = require("./utils");
const { elbowOffset, shoulderOffset, upperLegLength, lowerLegLength } = require("../config").physical;

// ===== TURN TUNING (adjust only these to change turn strength) =====
const TURN_GAIN = 1.2;          // 0.5 slow turn ... 1.2 fast turn
const MIN_STRIDE_SCALE = 0.35;  // prevents one side from going to zero
const MAX_STRIDE_SCALE = 1.65;  // prevents extreme over-stride
// ==================================================================

const inversePositioning = (coords, left) => {
    const { x, y, z } = coords;
    const L = 2;

    let y_prime = -Math.sqrt((z + L) ** 2 + y ** 2);

    const thetaZ =
        Math.atan2(z + L, Math.abs(y)) - Math.atan2(L, Math.abs(y_prime));

    // Keep existing adjustment logic (does not command hip anymore)
    if (left) {
        if (z !== 0) y_prime = -Math.sqrt((z + L) ** 2 + (y + thetaZ * 5) ** 2);
    } else {
        if (z !== 0) y_prime = -Math.sqrt((z + L) ** 2 + (y - thetaZ * 5) ** 2);
    }

    const a1 = upperLegLength;
    const a2 = lowerLegLength;

    let c2 = (x ** 2 + y_prime ** 2 - a1 ** 2 - a2 ** 2) / (2 * a1 * a2);

    // Safety clamp to avoid NaN if geometry is near limit
    c2 = clamp(c2, -1.0, 1.0);

    let s2 = Math.sqrt(1 - c2 ** 2);
    let theta2 = Math.atan2(s2, c2);

    c2 = Math.cos(theta2);
    s2 = Math.sin(theta2);

    const denom = (x ** 2 + y_prime ** 2);

    const c1 =
        (x * (a1 + a2 * c2) + y_prime * (a2 * s2)) / denom;
    const s1 =
        (y_prime * (a1 + a2 * c2) - x * (a2 * s2)) / denom;

    let theta1 = Math.atan2(s1, c1);

    let thetaShoulder = -theta1;
    let thetaElbow = thetaShoulder - theta2;

    // ================================
    // HIP DISABLED: keep fixed at 90°
    // ================================
    const thetaHip = 90;

    if (left) {
        thetaShoulder = 180 - radToDegree(thetaShoulder) + shoulderOffset;
        thetaElbow = 130 - radToDegree(thetaElbow) + elbowOffset;
    } else {
        thetaShoulder = radToDegree(thetaShoulder) - shoulderOffset;
        thetaElbow = 50 + radToDegree(thetaElbow) - elbowOffset;
    }

    return { thetaShoulder, thetaElbow, thetaHip };
};

const applyMomentumToCurve3d = (momentum, curve3d, inverse) => {
    const minZ = curve3d.reduce((min, p) => (p.z < min ? p.z : min), curve3d[0].z);
    const maxZ = curve3d.reduce((max, p) => (p.z > max ? p.z : max), curve3d[0].z);

    // We treat lateral as TURN command now (yaw), not side-step
    const turn = clamp(momentum.lateral, -1.0, 1.0);

    // speed should react to forward or turn demand
    const speed = clamp(
        Math.max(Math.abs(momentum.longitudinal), Math.abs(turn)),
        0.0,
        1.0
    );

    const trajectory = curve3d.map(point => {
        return {
            // forward/back stride stays here
            x: point.x * momentum.longitudinal,

            // side-step disabled (we will turn by left/right stride scaling)
            y: 0,

            // lift shaping stays similar but uses speed based on forward/turn
            z: point.z * inverse
                ? lerp(maxZ, point.z, speed)
                : lerp(point.z, minZ, 1.0 - speed),
        };
    });

    const x = trajectory.map(point => point.x);
    const y = trajectory.map(point => point.z + (1 - momentum.vertical) * 6);
    const z = trajectory.map(point => point.y); // always 0 now

    return { x, y, z };
};

// NOTE: Now takes momentum so it can apply differential turning
const mapCoordsToLegs = (index, curvePoints, momentum) => {
    const { x, y, z } = curvePoints;
    const numPoints = x.length;

    let f1 = index % numPoints;
    let f2 = (index + numPoints / 2) % numPoints;

    // A/D turn input
    const turn = clamp(momentum.lateral, -1.0, 1.0);

    // Differential stride scaling:
    // turn > 0 => turn RIGHT (right side longer stride, left side shorter)
    // turn < 0 => turn LEFT  (left side longer stride, right side shorter)
    const leftScale  = clamp(1.0 + TURN_GAIN * (-turn), MIN_STRIDE_SCALE, MAX_STRIDE_SCALE);
    const rightScale = clamp(1.0 + TURN_GAIN * ( turn), MIN_STRIDE_SCALE, MAX_STRIDE_SCALE);

    return {
        // Left legs
        fl: { x: x[f2] * leftScale,  y: y[f2], z: z[f2] },
        bl: { x: x[f1] * leftScale,  y: y[f1], z: 0 },

        // Right legs
        fr: { x: x[f1] * rightScale, y: y[f1], z: z[f1] },
        br: { x: x[f2] * rightScale, y: y[f2], z: 0 },
    };
};

module.exports = {
    inversePositioning,
    applyMomentumToCurve3d,
    mapCoordsToLegs
};

