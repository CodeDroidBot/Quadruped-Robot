const chalk = require('chalk');
const config = require('../config');
const utils = require('./utils');

let i2cBus;
let Pca9685Driver;
let pca9685ODevice;
let Gpio; // Add for OE pin control

// load dummy drivers if modules aren't installed
try {
    i2cBus = require('i2c-bus');
    Pca9685Driver = require('pca9685').Pca9685Driver;
    Gpio = require('onoff').Gpio; // For GPIO control
    console.log(chalk.green('Hardware libraries OK!'));
} catch (error) {
    console.log(chalk.yellowBright('Hardware libraries not available! Simulating servo output.'));
    i2cBus = require('./dummyHardware').dummyI2C;
    Pca9685Driver = require('./dummyHardware').dummyPCA;
    Gpio = require('./dummyHardware').dummyGpio; // Add dummy GPIO
}

const pca9685Options = {
    i2c: i2cBus.openSync(config.pca9685.i2cDevice),
    address: config.pca9685.address,
    frequency: config.pca9685.frequency,
    debug: config.pca9685.debug
};

class Servo {
    channel = 0;
    offset = 0;
    isReady = false;
    isBusy = false;

    constructor(motor) {
        this.channel = motor.channel;
        this.offset = motor.offset;
    }

    init() {
        // Change for DS3235 180-degree mode: 1000-2000µs
        pca9685ODevice.setPulseRange(this.channel, 1000, 2000);
        this.isReady = true;
    }

    setAngle(degrees) {
        // writing to the servo fast repeatedly without waiting until the callback is resolved causes memory overflow
        if (!this.isBusy) {
            this.isBusy = true;
            let newDegrees = degrees + this.offset;
            
            // Clamp to 0-180 for DS3235 180-degree mode
            if (newDegrees < 0) newDegrees = 0;
            if (newDegrees > 180) newDegrees = 180;
            
            // Map to DS3235 180-degree mode (1000-2000µs)
            const pulseLength = 1000 + (newDegrees / 180) * 1000;
            
            pca9685ODevice.setPulseLength(this.channel, pulseLength, 2000, 
                () => this.isBusy = false);
        }
    }
}

class ServoController {
    servos = [];
    isReady = false;
    isPowerOn = false; // Start with power off
    oePin = null;

    constructor() {
        this.servos = Object.keys(config.motors).map((key) => {
            return new Servo(config.motors[key]);
        });
        
        // Initialize OE pin (GPIO17) if hardware is available
        if (Gpio) {
            try {
                this.oePin = new Gpio(17, 'high'); // Active low, so 'high' = disabled
                console.log(chalk.green('OE pin initialized (GPIO17) - Servos DISABLED'));
            } catch (error) {
                console.log(chalk.yellow('Failed to initialize OE pin:', error.message));
            }
        }
        
        this.initialize().then(() => {
            this.servos.forEach(servo => servo.init());
            
            // Set all servos to neutral positions BEFORE enabling outputs
            this.calibrateToNeutral().then(() => {
                this.isReady = true;
                console.log(chalk.green('All servos at neutral positions'));
            });
            
        }).catch(err => {
            console.error("Error initializing PCA9685!", err);
            process.exit(-1);
        });
    }

    // Set all servos to default angles from config
    calibrateToNeutral() {
        return new Promise((resolve) => {
            console.log(chalk.blue('Setting servos to neutral positions...'));
            
            const promises = Object.keys(config.motors).map(key => {
                return new Promise((servoResolve) => {
                    const motor = config.motors[key];
                    const servo = this.servos.find(s => s.channel === motor.channel);
                    
                    // Use setTimeout to stagger servo movements
                    setTimeout(() => {
                        servo.setAngle(motor.defaultAngle);
                        servoResolve();
                    }, motor.channel * 10); // Stagger by channel number
                });
            });
            
            Promise.all(promises).then(() => {
                // Wait extra time for servos to reach position
                setTimeout(resolve, 1000);
            });
        });
    }

    setAngle(channel, degrees) {
        if (this.isPowerOn) {
            const servo = this.servos.find(servo => servo.channel === channel);
            servo.setAngle(degrees);
        }
    }

    setPower(powerOn) {
        if (powerOn && !this.isPowerOn) {
            // ENABLE SERVOS (OE = LOW)
            if (this.oePin) {
                this.oePin.writeSync(0); // Active low: 0 = enabled
                console.log(chalk.green('OE pin: LOW - Servos ENABLED'));
            }
            this.isPowerOn = true;
            
            // Give servos time to power up
            setTimeout(() => {
                if (pca9685ODevice.channelOn) {
                    this.servos.forEach(servo => {
                        pca9685ODevice.channelOn(servo.channel);
                    });
                }
            }, 100);
            
        } else if (!powerOn && this.isPowerOn) {
            // DISABLE SERVOS (OE = HIGH)
            this.isPowerOn = false;
            
            if (pca9685ODevice.allChannelsOff) {
                pca9685ODevice.allChannelsOff();
            }
            
            if (this.oePin) {
                this.oePin.writeSync(1); // Active low: 1 = disabled
                console.log(chalk.yellow('OE pin: HIGH - Servos DISABLED'));
            }
        }
    }

    // Graceful shutdown
    shutdown() {
        console.log(chalk.blue('Shutting down servos...'));
        this.setPower(false);
        if (this.oePin) {
            this.oePin.unexport(); // Clean up GPIO
        }
    }

    initialize() {
        return new Promise((resolve, reject) => {
            pca9685ODevice = new Pca9685Driver(pca9685Options, (err) => {
                if (err) {
                    reject(err);
                } else {
                    console.log(chalk.green('PCA9685 initialized (outputs disabled)'));
                    resolve();
                }
            });
        });
    }
}

module.exports = ServoController;
