const express = require('express');
const http = require('http');
const { Server: Robot } = require("socket.io");
const app = express();
const server = http.createServer(app);
const io = new Robot(server);
const { Worker } = require('worker_threads');
const config = require("./config");

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/src/index.html');
});

const worker = new Worker('./src/thread');

// Handle graceful shutdown
const cleanup = () => {
    console.log('\n' + '='.repeat(50));
    console.log('Shutting down gracefully...');
    console.log('='.repeat(50));
    
    // Send shutdown signal to worker
    worker.postMessage({ action: "shutdown" });
    
    // Wait for cleanup, then exit
    setTimeout(() => {
        console.log('Server stopped.');
        process.exit(0);
    }, 1500);
};

// Capture termination signals
process.on('SIGINT', cleanup);  // Ctrl+C
process.on('SIGTERM', cleanup); // Termination signal

worker.on('error', (error) => {
    console.error('Error in worker: ', error);
    cleanup();
});

worker.on('exit', (code) => {
    if (code !== 0) {
        console.error(`Worker stopped with exit code ${code}.`);
    }
    // Don't exit here, let cleanup handle it
});

worker.on('message', (message) => {
    if (message === 'ready') {
        console.log('✓ Robot worker is ready');
    }
});

io.on('connection', (socket) => {
    console.log('Web UI: User connected');
    socket.on('keydown', (keyCode) => {
        worker.postMessage({ action: "keydown", keyCode });
    });
    socket.on('keyup', (keyCode) => {
        worker.postMessage({ action: "keyup", keyCode });
    });

    socket.on('disconnect', () => {
        console.log('Web UI: User disconnected');
    });
});

server.listen(config.port, () => {
    console.log(`\n✦ Robot web UI is running on port ${config.port} ✦`);
    console.log(`Open http://localhost:${config.port} in your browser`);
    console.log('Press Ctrl+C to stop\n');
});
