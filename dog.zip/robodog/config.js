const config = {
    port: 3000,
    accel: 2.5,
    loopDelayMs: 15,    // 🔧 reduced for finer motion steps

    calibrate: false,   // keep false for normal operation

    motors: {
        FR_SHOULDER: { channel: 12, defaultAngle: 90, offset: 0, min: 20, max: 160 },
        FR_ELBOW:    { channel: 13, defaultAngle: 90, offset: 0, min: 20, max: 160 },
        FR_HIP:      { channel: 14, defaultAngle: 90, offset: 0, min: 60, max: 120 },

        FL_SHOULDER: { channel: 8,  defaultAngle: 90, offset: -4, min: 20, max: 160 },
        FL_ELBOW:    { channel: 9,  defaultAngle: 90, offset: 0, min: 20, max: 160 },
        FL_HIP:      { channel: 10, defaultAngle: 90, offset: 0, min: 60, max: 120 },

        BR_SHOULDER: { channel: 0,  defaultAngle: 90, offset: 0, min: 20, max: 160 },
        BR_ELBOW:    { channel: 1,  defaultAngle: 90, offset: 0, min: 20, max: 160 },
        BR_HIP:      { channel: 2,  defaultAngle: 90, offset: 0, min: 60, max: 120 },

        BL_SHOULDER: { channel: 4,  defaultAngle: 90, offset: 0, min: 20, max: 160 },
        BL_ELBOW:    { channel: 5,  defaultAngle: 90, offset: 0, min: 20, max: 160 },
        BL_HIP:      { channel: 6,  defaultAngle: 90, offset: 0, min: 60, max: 120 }
    },

    pca9685: {
        i2cDevice: 1,
        address: 0x40,
        frequency: 50,
        debug: false
    },

    physical: {
        elbowOffset: 20,
        shoulderOffset: 10,
        upperLegLength: 10,
        lowerLegLength: 10
    },

    servoLimits: {
        min: 0,
        max: 180,
        neutral: 90
    }
};

module.exports = config;
