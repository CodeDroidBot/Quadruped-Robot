

const { parentPort } = require('worker_threads');
const chalk = require('chalk');
const Gait = require("./gaitController");
const ServoController = require("./servoController");
const { calibrate } = require("../config");
const { inputController, keyPressHandler } = require("./inputController");

let servoController;

parentPort.on('message', (message) => {
    if (message.action === "shutdown") {
        console.log(chalk.red('Shutdown signal received'));
        if (servoController) {
            servoController.shutdown();
        }
        setTimeout(() => {
            process.exit(0);
        }, 500);
    } else {
        keyPressHandler(message);
    }
});

const startRobot = () => {
    console.log(chalk.blue("Robodog starting..."));
    
    servoController = new ServoController();
    
    const checkServoIsReady = () => {
        if (servoController.isReady) {
            console.log(chalk.gray("Servo controller ready!"));
            
            setTimeout(() => {
                servoController.setPower(true);
                
                const gaitController = new Gait(servoController);
                gaitController.calibrate();
                
                if (!calibrate) {
                    // 🐕 Give servos time to reach neutral before moving
                    setTimeout(() => {
                        console.log(chalk.green("Starting movement controller..."));
                        gaitController.move(inputController);
                        parentPort.postMessage('ready');
                    }, 2000); // was 1000 – now servos are stable
                } else {
                    console.log(chalk.yellow("Calibration mode active - servos at neutral"));
                    parentPort.postMessage('ready');
                }
            }, 500);
            
        } else {
            console.log(chalk.gray("Waiting for servo controller to be ready..."));
            setTimeout(checkServoIsReady, 250);
        }
    };
    
    checkServoIsReady();
};

startRobot();
