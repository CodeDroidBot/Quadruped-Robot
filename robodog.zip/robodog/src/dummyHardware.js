const dummyI2C = {
    openSync: (val) => {
        console.log('Dummy I2C opened');
        return {};
    }
}

class dummyPCA {
    constructor(options, callback) {
        const bus = options.i2c;
        console.log('Dummy PCA9685 initialized');
        if (callback) setTimeout(() => callback(), 10);
    }
    
    setPulseRange(channel, low, hi, callback) {
        console.log(`Dummy: Channel ${channel} pulse range ${low}-${hi}µs`);
        if (callback) setTimeout(() => callback(), 3);
    }
    
    setPulseLength(channel, pulseLength, out_max, callback) {
        console.log(`Dummy: Channel ${channel} pulse ${pulseLength}µs`);
        if (callback) setTimeout(() => callback(), 3);
    }
    
    allChannelsOff() {
        console.log('Dummy: All channels OFF');
    }
    
    channelOn(channel) {
        console.log(`Dummy: Channel ${channel} ON`);
    }
}

// Dummy GPIO for OE pin simulation
class dummyGpio {
    constructor(pin, direction) {
        this.pin = pin;
        this.state = direction === 'high' ? 1 : 0;
        console.log(`Dummy GPIO${pin} initialized as ${direction} (servos ${direction === 'high' ? 'DISABLED' : 'ENABLED'})`);
    }
    
    writeSync(value) {
        this.state = value;
        console.log(`Dummy GPIO${this.pin}: ${value ? 'HIGH' : 'LOW'} (${value ? 'Disabled' : 'Enabled'})`);
    }
    
    unexport() {
        console.log(`Dummy GPIO${this.pin} unexported`);
    }
}

module.exports = { 
    dummyI2C, 
    dummyPCA,
    dummyGpio 
};






